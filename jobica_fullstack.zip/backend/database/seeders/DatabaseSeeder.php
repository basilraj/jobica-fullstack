<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        DB::table('categories')->insert([
            ['name'=>'UPSC','slug'=>'upsc'],
            ['name'=>'SSC','slug'=>'ssc'],
            ['name'=>'Banking','slug'=>'banking'],
            ['name'=>'Railways','slug'=>'railways'],
            ['name'=>'Defence','slug'=>'defence'],
        ]);

        DB::table('jobs')->insert([
            ['title'=>'Assistant Engineer - Railways','department'=>'Railways','location'=>'Delhi','description'=>'Job description for Assistant Engineer.','apply_link'=>'http://example.com/apply','category_id'=>4,'last_date'=>'2025-12-31','created_at'=>now(),'updated_at'=>now()],
            ['title'=>'Bank Clerk','department'=>'Banking Dept','location'=>'Mumbai','description'=>'Bank clerk vacancy.','apply_link'=>'http://example.com/apply','category_id'=>3,'last_date'=>'2025-11-30','created_at'=>now(),'updated_at'=>now()],
            ['title'=>'SSC Graduate Level','department'=>'SSC Department','location'=>'All India','description'=>'Graduate level exam notification.','apply_link'=>'http://example.com/apply','category_id'=>2,'last_date'=>'2025-10-15','created_at'=>now(),'updated_at'=>now()],
        ]);

        DB::table('notices')->insert([
            ['title'=>'Railways Admit Card - 2025','pdf_path'=>'notices/railways-admit.pdf','type'=>'admit_card','created_at'=>now(),'updated_at'=>now()],
            ['title'=>'UPSC Final Result 2025','pdf_path'=>'notices/upsc-result.pdf','type'=>'result','created_at'=>now(),'updated_at'=>now()],
        ]);

        DB::table('users')->insert([
            ['name'=>'Admin','email'=>'admin@jobica.local','password'=>bcrypt('password'), 'role'=>'admin','created_at'=>now(),'updated_at'=>now()]
        ]);
    }
}
