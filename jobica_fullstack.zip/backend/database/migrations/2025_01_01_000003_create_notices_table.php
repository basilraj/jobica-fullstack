<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNoticesTable extends Migration
{
    public function up()
    {
        Schema::create('notices', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('pdf_path')->nullable();
            $table->enum('type',['admit_card','result'])->default('admit_card');
            $table->timestamps();
        });
    }
    public function down(){ Schema::dropIfExists('notices'); }
}
